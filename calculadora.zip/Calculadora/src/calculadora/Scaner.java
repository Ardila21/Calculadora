
package calculadora;

import java.util.Scanner;



public class Scaner {
     public static void main(String[] args) {
    
    Scanner obj1= new Scanner(System.in);
    Calculadora obj2 = new Calculadora();
    System.out.println("Ingrese primer valor: ");
    obj2.num1=obj1.nextFloat();
    System.out.println("Ingrese segundo valor: ");
    obj2.num2=obj1.nextFloat();
    System.out.println("la suma es: "+obj2.suma(obj2.num1,obj2.num2));
    System.out.println("la resta es: "+obj2.resta(obj2.num1,obj2.num2));
    System.out.println("la multiplicacion es: "+obj2.multiplicacion(obj2.num1,obj2.num2));
    System.out.println("la divicion es: "+obj2.divicion(obj2.num1,obj2.num2));
    System.out.println("el resultado de la potencia es: "+obj2.potencia(obj2.num1,obj2.num2));
    System.out.println("el resultado de la raiz es: "+obj2.raiz(obj2.num1,obj2.num2));
     System.out.println("el nuevo precio con iva es: "+obj2.iva(obj2.num1,obj2.num2));
    double n=obj1.nextDouble();
    System.out.println("el coseno es: "+obj2.cos(n));
    System.out.println("el seno es: "+obj2.sen(n));
    System.out.println("la tangente es: "+obj2.tan(n));
    
    
     }
}
