
package calculadora;

public class Calculadora {
     public float num1;
     public float num2;
     public float resul;

 public float suma(float a, float b){
       return a+b;
   }
   public float resta (float a, float b){
       return a-b;
   }
   public float multiplicacion (float a, float b){
       return a*b;
   }
   public float divicion (float a, float b){
       return a/b; 
   }
    public double potencia (float a, float b){
       return Math.pow(a,b);
   }
     public double raiz (float a, float b){
       return Math.pow(a,1/b);
   }
    public double sen(double n){
       return Math.sin(n);
   }
   public double cos(double n){
       return Math.cos(n);
   }
   public double tan(double n){
       return Math.tan(n);
   }
    public float iva (float a, float b){
       return a+(a*(b/100));
    }
}
